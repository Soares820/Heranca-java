class Empregado extends Pessoa {
    float salario;
    String matricula;

    Empregado(String nome, int idade, char sexo, float salario, String matricula) {
        super(nome, idade, sexo);
        this.salario = salario;
        this.matricula = matricula;
    }

    float valorINSS() {
        return salario * 0.11f;
    }

    @Override
    void obterInformacoesBasicas() {
        super.obterInformacoesBasicas();
        System.out.println("Salário: R$ " + salario + ", Matrícula: " + matricula + ", INSS: R$ " + valorINSS());
    }
}
