class Cliente extends Pessoa {
    float valorDivida;
    int anoNascimento;

    Cliente(String nome, int idade, char sexo, float valorDivida, int anoNascimento) {
        super(nome, idade, sexo);
        this.valorDivida = valorDivida;
        this.anoNascimento = anoNascimento;
    }

    @Override
    void obterInformacoesBasicas() {
        super.obterInformacoesBasicas();
        System.out.println("Valor da Dívida: R$ " + valorDivida + ", Ano de Nascimento: " + anoNascimento);
    }
}
