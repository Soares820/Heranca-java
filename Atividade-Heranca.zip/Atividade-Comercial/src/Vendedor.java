class Vendedor extends Empregado {
    int qtdVendas;
    float valorVenda;

    Vendedor(String nome, int idade, char sexo, float salario, String matricula, int qtdVendas, float valorVenda) {
        super(nome, idade, sexo, salario, matricula);
        this.qtdVendas = qtdVendas;
        this.valorVenda = valorVenda;
    }

    float totalVenda() {
        return qtdVendas * valorVenda;
    }

    @Override
    void obterInformacoesBasicas() {
        super.obterInformacoesBasicas();
        System.out.println("Quantidade de Vendas: " + qtdVendas + ", Valor da Venda: R$ " + valorVenda +
                ", Total de Vendas: R$ " + totalVenda());
    }
}
