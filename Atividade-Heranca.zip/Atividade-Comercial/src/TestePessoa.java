public class TestePessoa {
    public static void main(String[] args) {
        Empregado empregado = new Empregado("Carlos", 30, 'M', 5000, "EMP123");
        Gerente gerente = new Gerente("Ana", 40, 'F', 8000, "GER456", "TI");
        Cliente cliente = new Cliente("João", 25, 'M', 2000, 1999);
        Vendedor vendedor = new Vendedor("Pedro", 28, 'M', 3000, "VEN789", 50, 100);

        empregado.obterInformacoesBasicas();
        System.out.println();

        gerente.obterInformacoesBasicas();
        System.out.println();

        cliente.obterInformacoesBasicas();
        System.out.println();

        vendedor.obterInformacoesBasicas();
    }
}
