class Pessoa {
    String nome;
    int idade;
    char sexo;

    Pessoa(String nome, int idade, char sexo) {
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
    }

    void obterInformacoesBasicas() {
        System.out.println("Nome: " + nome + ", Idade: " + idade + ", Sexo: " + sexo);
    }
}
