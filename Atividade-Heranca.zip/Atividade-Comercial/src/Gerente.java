class Gerente extends Empregado {
    String nomeGerencia;

    Gerente(String nome, int idade, char sexo, float salario, String matricula, String nomeGerencia) {
        super(nome, idade, sexo, salario, matricula);
        this.nomeGerencia = nomeGerencia;
    }

    @Override
    void obterInformacoesBasicas() {
        super.obterInformacoesBasicas();
        System.out.println("Gerência: " + nomeGerencia);
    }
}
