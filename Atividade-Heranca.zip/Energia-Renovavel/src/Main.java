public class Main {
    public static void main(String[] args) {

        PlacaSolar[] placas = new PlacaSolar[3];


        placas[0] = new PlacaSolar(new EquipamentoEletrico(500, "SolarTech"), new DispositivoMonitoramento("Temperatura"));
        placas[1] = new PlacaSolar(new EquipamentoEletrico(700, "EcoPower"), new DispositivoMonitoramento("Luminosidade"));
        placas[2] = new PlacaSolar(new EquipamentoEletrico(600, "SunBright"), new DispositivoMonitoramento("Corrente"));

        
        System.out.println("Placas solares com sensores específicos:");
        for (PlacaSolar placa : placas) {
            if (placa.getDispositivo().getTipoSensor() != null) {
                placa.exibirDetalhes();
                System.out.println();
            }
        }
    }
}
