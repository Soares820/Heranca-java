class Conta {
    String cliente;
    String dataAbertura;
    double saldo;

    Conta(String cliente, String dataAbertura, double saldo) {
        if (saldo < 0) {
            throw new IllegalArgumentException("Erro: Saldo não pode ser negativo.");
        }
        this.cliente = cliente;
        this.dataAbertura = dataAbertura;
        this.saldo = saldo;
    }

    void depositar(double valor) {
        saldo += valor;
    }

    void sacar(double valor) {
        if (valor > saldo) {
            System.out.println("Erro: Saque não permitido. Saldo disponível: R$ " + saldo);
        } else {
            saldo -= valor;
        }
    }

    void verSaldo() {
        System.out.println("Saldo atual: R$ " + saldo);
    }
}
