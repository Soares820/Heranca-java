public class TesteContas {
    public static void main(String[] args) {
        Poupanca contaPoupanca = new Poupanca("João", "01/04/2025", 1000, 0.5);
        ContaCorrente contaCorrente = new ContaCorrente("Maria", "02/04/2025", 1500, 10);


        contaPoupanca.aplicarRendimento();
        contaPoupanca.verSaldo();

        contaCorrente.verSaldo();
        contaCorrente.sacar(200);
        contaCorrente.verSaldo();
    }
}
