class ContaCorrente extends Conta {
    double taxaMovimentacao;

    ContaCorrente(String cliente, String dataAbertura, double saldo, double taxaMovimentacao) {
        super(cliente, dataAbertura, saldo);
        this.taxaMovimentacao = taxaMovimentacao;
    }

    @Override
    void verSaldo() {
        saldo -= taxaMovimentacao;
        System.out.println("Saldo após taxa de movimentação: R$ " + saldo);
    }
}
