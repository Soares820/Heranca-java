class Poupanca extends Conta {
    double rendimentoMensal;

    Poupanca(String cliente, String dataAbertura, double saldo, double rendimentoMensal) {
        super(cliente, dataAbertura, saldo);
        this.rendimentoMensal = rendimentoMensal;
    }

    void aplicarRendimento() {
        saldo += saldo * rendimentoMensal / 100;
    }
}
