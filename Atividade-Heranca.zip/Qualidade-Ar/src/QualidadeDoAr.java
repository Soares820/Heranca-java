import java.util.ArrayList;
import java.util.Scanner;

public class QualidadeDoAr {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Monitoramento> estacoes = new ArrayList<>();

        System.out.print("Quantas estações deseja cadastrar? ");
        int numEstacoes = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer

        for (int i = 0; i < numEstacoes; i++) {
            System.out.print("Digite a localização da estação " + (i + 1) + ": ");
            String localizacao = scanner.nextLine();

            System.out.print("Digite o índice de qualidade do ar para " + localizacao + ": ");
            int indice = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer

            estacoes.add(new Monitoramento(localizacao, indice));
        }

        // Cálculo da média
        int soma = 0;
        for (Monitoramento estacao : estacoes) {
            soma += estacao.getIndiceQualidadeAr();
        }

        double media = (estacoes.size() > 0) ? (double) soma / estacoes.size() : 0;

        System.out.println("\nMédia do índice de qualidade do ar da cidade: " + media);

        scanner.close();
    }
}
