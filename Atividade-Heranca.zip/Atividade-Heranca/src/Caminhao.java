class Caminhao extends Veiculo {
    double tonelada, alturaMaxima, comprimento;

    Caminhao(double peso, double velocidadeMaxima, double preco, double tonelada, double alturaMaxima, double comprimento) {
        super(peso, velocidadeMaxima, preco);
        this.tonelada = tonelada;
        this.alturaMaxima = alturaMaxima;
        this.comprimento = comprimento;
    }

    void obterInformacoesBasicas() {
        super.obterInformacoesBasicas();
        System.out.println("Tonelada: " + tonelada + " t, Altura Máxima: " + alturaMaxima + " m, Comprimento: " + comprimento + " m");
    }
}
