class Veiculo {
    double peso, velocidadeMaxima, preco;

    Veiculo() {}

    Veiculo(double peso, double velocidadeMaxima, double preco) {
        this.peso = peso;
        this.velocidadeMaxima = velocidadeMaxima;
        this.preco = preco;
    }

    void obterInformacoesBasicas() {
        System.out.println("Peso: " + peso + " kg, Velocidade Máxima: " + velocidadeMaxima + " km/h, Preço: R$ " + preco);
    }
}
