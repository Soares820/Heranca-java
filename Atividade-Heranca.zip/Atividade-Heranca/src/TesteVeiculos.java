public class TesteVeiculos {
    public static void main(String[] args) {
        CarroPasseio carro = new CarroPasseio(1200, 180, 75000, "Toyota", "Vermelho");
        Caminhao caminhao = new Caminhao(8000, 120, 250000, 15, 4, 12);

        carro.obterInformacoesBasicas();
        caminhao.obterInformacoesBasicas();
    }
}
