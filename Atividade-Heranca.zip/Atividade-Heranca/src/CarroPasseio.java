class CarroPasseio extends Veiculo {
    String marca, cor;

    CarroPasseio(double peso, double velocidadeMaxima, double preco, String marca, String cor) {
        super(peso, velocidadeMaxima, preco);
        this.marca = marca;
        this.cor = cor;
    }

    void obterInformacoesBasicas() {
        super.obterInformacoesBasicas();
        System.out.println("Marca: " + marca + ", Cor: " + cor);
    }
}
