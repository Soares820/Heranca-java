public class Main {
    public static void main(String[] args) {

        Produto[] produtos = new Produto[5];


        produtos[0] = new AlimentoOrganico("Maçã", 5.50, true);
        produtos[1] = new AlimentoOrganico("Banana", 3.00, false);
        produtos[2] = new AlimentoOrganico("Tomate", 4.25, true);
        produtos[3] = new AlimentoOrganico("Alface", 2.75, true);
        produtos[4] = new AlimentoOrganico("Cenoura", 3.80, false);


        System.out.println("Produtos orgânicos certificados:");
        for (Produto produto : produtos) {
            if (produto instanceof AlimentoOrganico) {
                AlimentoOrganico alimento = (AlimentoOrganico) produto;
                if (alimento.isCertificado()) {
                    System.out.println("- " + alimento.getNome() + " (R$ " + alimento.getPreco() + ")");
                }
            }
        }
    }
}
