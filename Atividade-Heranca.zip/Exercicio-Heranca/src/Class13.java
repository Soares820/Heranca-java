class Class13 {
    int atributo01;
    int atributo02;

    Class13(int atributo01, int atributo02) {
        this.atributo01 = atributo01;
        this.atributo02 = atributo02;
    }

    void metodo010() {
        System.out.println("Método comum da classe mãe.");
    }

    void mostrarAtributos() {
        System.out.println("Atributo01: " + atributo01 + ", Atributo02: " + atributo02);
    }
}
