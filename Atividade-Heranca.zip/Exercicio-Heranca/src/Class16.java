class Class16 extends Class13 {
    int atributo05;

    Class16(int atributo01, int atributo02, int atributo05) {
        super(atributo01, atributo02);
        this.atributo05 = atributo05;
    }

    void metodo040() {
        System.out.println("Método específico da Class16.");
    }

    @Override
    void mostrarAtributos() {
        super.mostrarAtributos();
        System.out.println("Atributo05: " + atributo05);
    }
}
