class Class15 extends Class13 {
    int atributo04;

    Class15(int atributo01, int atributo02, int atributo04) {
        super(atributo01, atributo02);
        this.atributo04 = atributo04;
    }

    void metodo030() {
        System.out.println("Método específico da Class15.");
    }

    @Override
    void mostrarAtributos() {
        super.mostrarAtributos();
        System.out.println("Atributo04: " + atributo04);
    }
}
