public class TesteHeranca {
    public static void main(String[] args) {
        Class14 obj1 = new Class14(10, 20, 30);
        Class15 obj2 = new Class15(40, 50, 60);
        Class16 obj3 = new Class16(70, 80, 90);

        obj1.mostrarAtributos();
        obj1.metodo010();
        obj1.metodo020();
        System.out.println();

        obj2.mostrarAtributos();
        obj2.metodo010();
        obj2.metodo030();
        System.out.println();

        obj3.mostrarAtributos();
        obj3.metodo010();
        obj3.metodo040();
    }
}
