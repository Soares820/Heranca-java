class Class14 extends Class13 {
    int atributo03;

    Class14(int atributo01, int atributo02, int atributo03) {
        super(atributo01, atributo02);
        this.atributo03 = atributo03;
    }

    void metodo020() {
        System.out.println("Método específico da Class14.");
    }

    @Override
    void mostrarAtributos() {
        super.mostrarAtributos();
        System.out.println("Atributo03: " + atributo03);
    }
}
